#include "pch.h"
#include "CGraphicObject.h"
